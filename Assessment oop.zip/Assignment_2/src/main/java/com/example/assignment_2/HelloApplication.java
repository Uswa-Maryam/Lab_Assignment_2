package com.example.assignment_2;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Admission Form");

        // Root layout
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        // Banner
        Label banner = new Label("Admission Form");
        banner.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-background-color: green; -fx-text-fill: white;");
        banner.setMinWidth(400);
        banner.setPadding(new Insets(10));
        root.getChildren().add(banner);

        // GridPane for form fields
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        // Labels and TextFields
        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label fatherNameLabel = new Label("Father Name:");
        TextField fatherNameField = new TextField();

        Label cityLabel = new Label("City:");
        ComboBox<String> cityComboBox = new ComboBox<>();
        cityComboBox.getItems().addAll("New York", "London", "Paris", "Tokyo");

        Label addressLabel = new Label("Address:");
        TextField addressField = new TextField();

        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();

        Label genderLabel = new Label("Gender:");
        RadioButton maleRadio = new RadioButton("Male");
        RadioButton femaleRadio = new RadioButton("Female");
        ToggleGroup genderGroup = new ToggleGroup();
        maleRadio.setToggleGroup(genderGroup);
        femaleRadio.setToggleGroup(genderGroup);

        Label imageLabel = new Label("Image:");
        Button imageButton = new Button("Choose File");
        ImageView imageView = new ImageView();
        imageView.setFitHeight(50);
        imageView.setFitWidth(50);
        imageButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Image Files", ".png", ".jpg", "*.jpeg")
            );
            try {
                Image image = new Image(fileChooser.showOpenDialog(primaryStage).toURI().toString());
                imageView.setImage(image);
            } catch (Exception ex) {
                // Handle error (e.g., file not selected)
            }
        });

        // Submit button
        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            String name = nameField.getText();
            String fatherName = fatherNameField.getText();
            String city = cityComboBox.getValue();
            String address = addressField.getText();
            String email = emailField.getText();
            RadioButton selectedGender = (RadioButton) genderGroup.getSelectedToggle();
            String gender = selectedGender != null ? selectedGender.getText() : "Not specified";

            // Add to array list or process data
            System.out.println("Name: " + name);
            System.out.println("Father Name: " + fatherName);
            System.out.println("City: " + city);
            System.out.println("Address: " + address);
            System.out.println("Email: " + email);
            System.out.println("Gender: " + gender);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Submission Successful");
            alert.setHeaderText(null);
            alert.setContentText("Data submitted successfully!");
            alert.showAndWait();
        });

        // Adding elements to the grid
        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(fatherNameLabel, 0, 1);
        grid.add(fatherNameField, 1, 1);
        grid.add(cityLabel, 0, 2);
        grid.add(cityComboBox, 1, 2);
        grid.add(addressLabel, 0, 3);
        grid.add(addressField, 1, 3);
        grid.add(emailLabel, 0, 4);
        grid.add(emailField, 1, 4);
        grid.add(genderLabel, 0, 5);
        grid.add(maleRadio, 1, 5);
        grid.add(femaleRadio, 1, 6);
        grid.add(imageLabel, 0, 7);
        grid.add(imageButton, 1, 7);
        grid.add(imageView, 2, 7);

        // Adding submit button
        grid.add(submitButton, 1, 8);

        // Add grid to root
        root.getChildren().add(grid);

        // Scene and stage setup
        Scene scene = new Scene(root, 450, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}